import argparse

# Create the argument parser object
parser = argparse.ArgumentParser(
    prog='`argparse` demo script',
    description='This script demonstrates basic features of Python\'s argparse library'
)

# Define the arguments the file can accept
parser.add_argument('-f', '--filename')
parser.add_argument('-v', '--verbose', action='store_true')  # How did I know what to put in `action`? Read the documentation!!!

# Parse the arguments that the user entered at the command line
args = parser.parse_args()

if (args.verbose):
    print(args)
    print()
    
if args.filename:
    with open(args.filename, 'r') as fp:
        file_contents = fp.readlines()
        print(file_contents)
        
else:
    print("No filename provided - please try again.")